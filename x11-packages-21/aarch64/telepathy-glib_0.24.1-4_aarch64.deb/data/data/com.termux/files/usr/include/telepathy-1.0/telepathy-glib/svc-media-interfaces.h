#if defined (TP_DISABLE_SINGLE_INCLUDE) && !defined (_TP_IN_META_HEADER) && !defined (_TP_COMPILATION)
#error "Only <telepathy-glib/telepathy-glib-dbus.h> can be included directly."
#endif

#ifndef __TP_SVC_MEDIA_INTERFACES_H__
#define __TP_SVC_MEDIA_INTERFACES_H__

#include <telepathy-glib/_gen/tp-svc-media-session-handler.h>
#include <telepathy-glib/_gen/tp-svc-media-stream-handler.h>

#endif

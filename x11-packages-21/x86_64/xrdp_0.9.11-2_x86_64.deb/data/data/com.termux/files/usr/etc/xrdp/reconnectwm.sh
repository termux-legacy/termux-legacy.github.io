#!/data/data/com.termux/files/usr/bin/sh

# Write procedures here you want to execute on reconnect

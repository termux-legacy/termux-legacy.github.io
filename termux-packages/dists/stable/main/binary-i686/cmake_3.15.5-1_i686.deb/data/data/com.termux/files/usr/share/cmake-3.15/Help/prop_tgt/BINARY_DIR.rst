BINARY_DIR
----------

This read-only property reports the value of the
:variable:`CMAKE_CURRENT_BINARY_DIR` variable in the directory in which
the target was defined.

INTERFACE_COMPILE_OPTIONS
-------------------------

.. |property_name| replace:: compile options
.. |command_name| replace:: :command:`target_compile_options`
.. |PROPERTY_INTERFACE_NAME| replace:: ``INTERFACE_COMPILE_OPTIONS``
.. |PROPERTY_LINK| replace:: :prop_tgt:`COMPILE_OPTIONS`
.. |PROPERTY_GENEX| replace:: ``$<TARGET_PROPERTY:foo,INTERFACE_COMPILE_OPTIONS>``
.. include:: INTERFACE_BUILD_PROPERTY.txt

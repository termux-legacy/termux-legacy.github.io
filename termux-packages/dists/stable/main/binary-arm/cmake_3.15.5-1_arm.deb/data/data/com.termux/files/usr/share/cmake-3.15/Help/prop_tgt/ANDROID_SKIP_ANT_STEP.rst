ANDROID_SKIP_ANT_STEP
---------------------

Set the Android property that defines whether or not to skip the Ant build step.
This is a boolean property initialized by the value of the
:variable:`CMAKE_ANDROID_SKIP_ANT_STEP` variable if it is set when a target is created.

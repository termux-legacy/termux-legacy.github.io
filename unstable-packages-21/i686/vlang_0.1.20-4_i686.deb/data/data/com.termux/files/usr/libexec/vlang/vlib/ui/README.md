# V UI

V UI is a cross-platform UI toolkit for Windows, macOS, Linux, Android, and iOS. It uses native widgets on each platform.

V UI is licensed under GPL3. A commercial license will be available.

Open-source projects will have access to the commercial license for free. That means that if you have an open-source non-GPL project, you won't have to relicense it under GPL to use V UI.

Every single feature will be open-sourced right away and available under both licenses.

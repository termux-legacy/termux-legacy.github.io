export LESSOPEN='|/data/data/com.termux/files/usr/bin/lesspipe.sh %s'
